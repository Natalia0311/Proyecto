#ifndef BASEDATOS_H
#define BASEDATOS_H


class basedatos
{
public:
    basedatos();
};

#endif // BASEDATOS_H