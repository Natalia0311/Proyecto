#include "basedatos.h"

basedatos::basedatos()
{

}
